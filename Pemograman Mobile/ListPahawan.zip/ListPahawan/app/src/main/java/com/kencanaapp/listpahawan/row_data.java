package com.kencanaapp.listpahawan;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class row_data extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.row_data);
  }
}
