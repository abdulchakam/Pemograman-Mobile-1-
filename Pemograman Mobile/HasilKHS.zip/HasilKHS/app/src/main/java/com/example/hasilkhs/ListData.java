package com.example.hasilkhs;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListData extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_data);
    }
}
